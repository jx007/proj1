package semi;

import java.io.Serializable;

public class NetData implements Serializable{
	

	private static final long serialVersionUID = 5678L;
	String id, kind;
	Object data;
}
