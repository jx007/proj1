package semi;

import java.io.Serializable;

public abstract class SubData implements Serializable{

	private static final long serialVersionUID = 1234L;
	 public	abstract void execute();
}
